package com.zc.mybatisplus.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zc.mybatisplus.entity.Users;

public interface UserService extends IService<Users> {

}
