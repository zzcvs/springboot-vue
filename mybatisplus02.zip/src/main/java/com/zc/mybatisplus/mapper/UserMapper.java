package com.zc.mybatisplus.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zc.mybatisplus.entity.Users;

public interface UserMapper extends BaseMapper<Users> {


}
